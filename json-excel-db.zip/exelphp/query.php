<?php

$servername = "localhost";
$dbusername = "root";
$password = "";
$dbname = "origin";

$id=1;

$username='vale';

$code='vale';

$first_name='vale';
// $first_name = str_replace(',', '.', $first_name);

$last_name='vale';

$birth_date='vale';

$phone_number='vale';

$email='vale';

$gender='vale';

$street='vale';
// $street = mysqli_escape_string($street);
$street = str_replace(array('\'', '"', '\\'), array('', '', ''), $street);

$street_number='vale';

$city='vale';

$location='vale';

$registration_date='vale';

$registered_on_location='vale';

$uuid='vale';

$card_code='vale';

$pay_in='vale';

$win='vale';

var_dump($_SERVER['REQUEST_URI']);

if($_SERVER['REQUEST_URI'] === '/') {

		try {
			    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $dbusername, $password);
			    // set the PDO error mode to exception
			    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    $sql = "INSERT INTO clients
						VALUES ('$id', '$username', '$code', '$first_name', '$last_name', '$birth_date', '$phone_number', '$email', '$gender', '$street', '$street_number', '$city', '$location', '$registration_date', '$registered_on_location', '$uuid', '$card_code', '$pay_in', '$win')";
			    // use exec() because no results are returned
			    $conn->exec($sql);
			    echo "New record created successfully";
			    }
			catch(PDOException $e)
			    {
			    echo $sql . "<br>" . $e->getMessage();
			    }

			$conn = null;
		}