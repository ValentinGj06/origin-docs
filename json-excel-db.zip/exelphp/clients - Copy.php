<?php

$servername = "localhost";
$dbusername = "root";
$password = "";
$dbname = "origin";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }
// echo "Connected successfully"."\n";

error_reporting(E_ERROR);
ini_set("display_errors", "On");

require_once 'Classes/PHPExcel.php';
//require_once 'session_check.php';
//require_once 'class_includer.php';
//require_once 'model_includer.php';
//require_once $uri_models . "helper_model.php";


$file = 'clients2.csv';                             
$handle = fopen($file, 'r+');
ftruncate($handle, 0);
fclose($handle);
$tempfname='clients2.xlsx'; 


$excelReader=PHPExcel_IOFactory::createReaderForFile($tempfname);
$excelObj=$excelReader->load($tempfname);
$worksheet=$excelObj->getActiveSheet();
$lastRow=$worksheet->getHighestRow();
$lastCol=$worksheet->getHighestColumn();
$worksheetTitle = $worksheet->getTitle();
$sheetCount = $excelObj->getSheetCount();
$SheetNames = $excelObj->getSheetNames();



for($row=2; $row<=$lastRow; $row++){


$id=$worksheet->getCell('A'.$row)->getValue();

$username=$worksheet->getCell('B'.$row)->getValue();

$code=$worksheet->getCell('C'.$row)->getValue();

$first_name=$worksheet->getCell('D'.$row)->getValue();
// $first_name = str_replace(',', '.', $first_name);

$last_name=$worksheet->getCell('E'.$row)->getValue();

$birth_date=$worksheet->getCell('F'.$row)->getValue();

$phone_number=$worksheet->getCell('G'.$row)->getValue();

$email=$worksheet->getCell('H'.$row)->getValue();

$gender=$worksheet->getCell('I'.$row)->getValue();

$street=$worksheet->getCell('J'.$row)->getValue();
// $street = mysqli_escape_string($street);
$street = str_replace(array('\'', '"', '\\'), array('', '', ''), $street);

$street_number=$worksheet->getCell('K'.$row)->getValue();

$city=$worksheet->getCell('L'.$row)->getValue();

$location=$worksheet->getCell('M'.$row)->getValue();

$registration_date=$worksheet->getCell('N'.$row)->getValue();

$registered_on_location=$worksheet->getCell('O'.$row)->getValue();

$uuid=$worksheet->getCell('P'.$row)->getValue();

$card_code=$worksheet->getCell('Q'.$row)->getValue();

$pay_in=$worksheet->getCell('R'.$row)->getValue();

$win=$worksheet->getCell('S'.$row)->getValue();


		

			try {
			    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $dbusername, $password);
			    // set the PDO error mode to exception
			    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    $sql = "INSERT INTO clients
						VALUES ('$id', '$username', '$code', '$first_name', '$last_name', '$birth_date', '$phone_number', '$email', '$gender', '$street', '$street_number', '$city', '$location', '$registration_date', '$registered_on_location', '$uuid', '$card_code', '$pay_in', '$win')";
			    // use exec() because no results are returned
			    $conn->exec($sql);
			    echo "New record created successfully";
			    }
			catch(PDOException $e)
			    {
			    echo $sql . "<br>" . $e->getMessage();
			    }

			$conn = null;
				                            

}
			


file_put_contents($file, $data, FILE_APPEND | LOCK_EX);


?>