<?php

header( 'content-type: text/html; charset=utf-8' );

$servername = "192.168.1.197";
$dbusername = "crm";
$password = "grankaTa*";
$dbname = "db_crm";

	try {
	    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $dbusername, $password);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    echo "Connection successfully"."<br>";
	    }
	catch(PDOException $e)
	    {
	    echo $sql . "<br>" . $e->getMessage();
	    }

error_reporting(E_ERROR);
ini_set("display_errors", "On");

require_once 'Classes/PHPExcel.php';

$file = 'clients.csv';                             
$handle = fopen($file, 'r+');
ftruncate($handle, 0);
fclose($handle);
$tempfname='clients.xlsx'; 


$excelReader=PHPExcel_IOFactory::createReaderForFile($tempfname);
$excelObj=$excelReader->load($tempfname);
$worksheet=$excelObj->getActiveSheet();
$lastRow=$worksheet->getHighestRow();
$lastCol=$worksheet->getHighestColumn();
$worksheetTitle = $worksheet->getTitle();
$sheetCount = $excelObj->getSheetCount();
$SheetNames = $excelObj->getSheetNames();

$i = 1;
$numeric = 0;
$not_numeric = 0;

for($row=2; $row<=$lastRow; $row++){

	$id=$worksheet->getCell('A'.$row)->getValue();

	$username=$worksheet->getCell('B'.$row)->getValue();
	if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
		echo "<span style='background-color: red'> $username ? </span>";
	}

	$code=$worksheet->getCell('C'.$row)->getValue();

	$first_name=$worksheet->getCell('D'.$row)->getValue();
	// $first_name = str_replace(',', '.', $first_name);

	$last_name=$worksheet->getCell('E'.$row)->getValue();

	$cell = $excelObj->getActiveSheet()->getCell('F'.$row);
	$InvDate= $cell->getValue();
	if(PHPExcel_Shared_Date::isDateTime($cell)) {
      $birth_date = date($format = "d.m.Y", PHPExcel_Shared_Date::ExcelToPHP($InvDate));
      }  
	$birth_date = strtotime($birth_date);
	$birth_date = date('Y-m-d', $birth_date); 
	echo $birth_date; //outputs 2020-10-27
	/** Registration date **/

	/** Phone number **/
	$phone_number=$worksheet->getCell('G'.$row)->getValue();

	// $phone_number = str_replace(array('\'', '"', '\\', '-', '/', '`', '.', ' '), array(''), $phone_number);
	$phone_number = str_replace('+', '00', $phone_number);
	$phone_number = preg_replace('/[^0-9]/', '', $phone_number);
	if(substr($phone_number, 0, 5) !== '00389' && substr($phone_number, 0, 1) === '0'){
		$phone_number = preg_replace('/^0/', '00389', $phone_number);
	}
	if(preg_match('/^[0][0-9]{8,12}$/', $phone_number)) {
		$numeric++;
		echo "<span style='background-color: grey'>".$i++."</span>" . " ".$phone_number."<br>";
		$is_valid_phone_number = true;
	} else {
		$not_numeric++;
		echo "<span style='background-color: yellow'>".$i++."</span>" ."<span style='background-color: red'> $phone_number ? </span>"."<br>";
		$is_valid_phone_number = false;
	};
	/** Phone number **/

	$email=$worksheet->getCell('H'.$row)->getValue();
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	  echo "<span style='background-color: red'> $email ? </span>"."<br>";
	}

	$gender=$worksheet->getCell('I'.$row)->getValue();

	$street=$worksheet->getCell('J'.$row)->getValue();
	// $street = mysqli_escape_string($street);
	$street = str_replace(array('\'', '"', '\\'), array('', '', ''), $street);

	$street_number=$worksheet->getCell('K'.$row)->getValue();

	$city=$worksheet->getCell('L'.$row)->getValue();

	$location=$worksheet->getCell('M'.$row)->getValue();

	/** Registration date **/
	$registration_date=$worksheet->getCell('N'.$row)->getValue();
	$registration_date = substr($registration_date, '0', '9');
	$registration_date = strtotime($registration_date);
	$registration_date = date('Y-m-d', $registration_date); 
	echo $registration_date; //outputs 2020-10-27
	/** Registration date **/

	$registered_on_location=$worksheet->getCell('O'.$row)->getValue();

	$uuid=$worksheet->getCell('P'.$row)->getValue();

	$card_number=$worksheet->getCell('Q'.$row)->getValue();

	$pay_in=$worksheet->getCell('R'.$row)->getValue();

	$win=$worksheet->getCell('S'.$row)->getValue();

	if($_SERVER['REQUEST_URI'] === '/update') {

	    $sql = "INSERT IGNORE INTO clients
				VALUES ('$id', '$username', '$uuid', '$registration_date', '$registered_on_location');";

		$sql .= "INSERT IGNORE INTO client_info
				VALUES ('$id', '$first_name', '$last_name', '$email', '$birth_date', '$phone_number', '$is_valid_phone_number', '$gender', '$street', '$street_number', '$city');";

		$sql .= "INSERT IGNORE INTO client_details
				VALUES ('$id', '$code', '$card_number', '$pay_in', '$win')";

	    /** UPDATE SOME ROWS **/
		// $sql = "UPDATE clients
		// 		SET username = '$username', uuid = '$uuid'
		// 		WHERE id = '$id'";
		/** UPDATE SOME ROWS **/

		// $sql = "INSERT IGNORE INTO client_details
		// 		VALUES ('$id', '$card_number')";

	    $conn->exec($sql);   
		
	}				                            
}
			
		$conn = null;
		echo "New records created successfully";

file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

echo "Total Numeric: " .$numeric."<br>";
echo "Total NOT Numeric оr NOT entered well: " .$not_numeric."<br>";
?>