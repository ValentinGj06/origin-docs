<?PHP
error_reporting(E_ERROR);
ini_set("display_errors", "On");

require_once 'Classes/PHPExcel.php';
//require_once 'session_check.php';
//require_once 'class_includer.php';
//require_once 'model_includer.php';
//require_once $uri_models . "helper_model.php";


$file = 'strelci_08_10-raboti.csv';                             
$handle = fopen($file, 'r+');
ftruncate($handle, 0);
fclose($handle);
$tempfname='strelci_08_10-raboti.xlsx'; 

$round =174;
$data="";

$excelReader=PHPExcel_IOFactory::createReaderForFile($tempfname);
$excelObj=$excelReader->load($tempfname);
$worksheet=$excelObj->getActiveSheet();
$lastRow=$worksheet->getHighestRow();
$lastCol=$worksheet->getHighestColumn();
$worksheetTitle = $worksheet->getTitle();
$sheetCount = $excelObj->getSheetCount();
$SheetNames = $excelObj->getSheetNames();

foreach ($SheetNames as $Name) {
            $Name;
                 }
$tr=1;
$hd=0;
$hg=0;
$game="";

for($row=1; $row<=$lastRow; $row++){
	$cell = $excelObj->getActiveSheet()->getCell('B' . $row);
    $InvDate= $cell->getValue();
    if(PHPExcel_Shared_Date::isDateTime($cell)) {
      $time = date($format = "d.m.y", PHPExcel_Shared_Date::ExcelToPHP($InvDate));  
}


$cell1 = $excelObj->getActiveSheet()->getCell('C' . $row);
$InvDate1= $cell1->getValue();
if(PHPExcel_Shared_Date::isDateTime($cell1)) {
$casx = date($format = "H:i", PHPExcel_Shared_Date::ExcelToPHP($InvDate1));  
}
$cas = strtotime ( '-2 Hours' , strtotime ( $casx ) ) ;
$cas = date ( 'H:i' , $cas );
//$cas=$worksheet->getCell('C'.$row)->getValue();
$code=$worksheet->getCell('D'.$row)->getValue();
$name_team=$worksheet->getCell('E'.$row)->getValue();
$name_team1=$worksheet->getCell('H'.$row)->getValue();
$od1=$worksheet->getCell('L'.$row)->getValue();
$odd1 = str_replace(',', '.', $od1);
$odX=$worksheet->getCell('M'.$row)->getValue();
$oddX = str_replace(',', '.', $odX);
$od2plus=$worksheet->getCell('N'.$row)->getValue();
$odd2plus = str_replace(',', '.', $od2plus);
$od3plus=$worksheet->getCell('O'.$row)->getValue();
$odd3plus = str_replace(',', '.', $od3plus);
$odgIgII=$worksheet->getCell('P'.$row)->getValue();
$oddgIgII = str_replace(',', '.', $odgIgII);

if($row<100)$name_league=$worksheet->getCell('B1')->getValue();//$name_league_sub = substr($name_league, -8);



if($worksheet->getCell('B'.$row)->getValue()=="" ||
		$row==1 || $row==2 || $row==3 || $row==4 || $row==5 || $row==6){

            $data.="";

 }
else{
          

         $data.=  
			 $round."#".$code."##".ucwords(strtolower($name_team))."#".$name_team1."#".$name_league."#".SF."##".$tr."#".$hd."#".$hg."#".$time."#".$cas."#".$odd1."#######################".$odd3plus."########################################################".$odd2plus."#############################################".$oddX."########################################################################################################".$oddgIgII."######################################################################################################################"."\n";
			$data.=  
			$round."#".$code."##".ucwords(strtolower($name_team))."#".$name_team1."#".$name_league."#".SF."##".$tr."#".$hd."#".$hg."#".$time."#".$cas."#".$odd1."#########".$oddX."##############".$odd3plus."########################################################".$odd2plus."#####################################################################################################################################################".$oddgIgII."######################################################################################################################"."\n";

				                            
}
}


for($row=1; $row<=$lastRow; $row++){

$code=$worksheet->getCell('T'.$row)->getValue();
$name_team=$worksheet->getCell('U'.$row)->getValue();
$name_team1=$worksheet->getCell('AC'.$row)->getValue();
//$cas=$worksheet->getCell('L'.$row)->getValue();

$od1=$worksheet->getCell('AI'.$row)->getValue();
$oddd1 = str_replace(',', '.', $od1);


$cell1 = $excelObj->getActiveSheet()->getCell('S' . $row);
$InvDate1= $cell1->getValue();
if(PHPExcel_Shared_Date::isDateTime($cell1)) {
$casx = date($format = "H:i", PHPExcel_Shared_Date::ExcelToPHP($InvDate1));  
}
$cas = strtotime ( '-2 Hours' , strtotime ( $casx ) ) ;
$cas = date ( 'H:i' , $cas );

$cell = $excelObj->getActiveSheet()->getCell('R' . $row);
$InvDate= $cell->getValue();
if(PHPExcel_Shared_Date::isDateTime($cell)) {
$time = date($format = "d.m.y", PHPExcel_Shared_Date::ExcelToPHP($InvDate));  
}


 if($row < 54)$name_league=$worksheet->getCell('R1')->getValue();
 
if($worksheet->getCell('R'.$row)->getValue()=="" ||
		$row==1 || $row==2 || $row==3 || $row==4 || $row==5){

            $data.="";

 }

else{
			$data.= 
			$round."#".$code."##".ucwords(strtolower($name_team))."#".ucwords(strtolower($name_team1))."#".$name_league."#".SF."##".$tr."#".$hd."#".$hg."#".$time."#".$cas."#".$oddd1."#######################################################################################################################################################################################################################################################################################################################################################################"."\n";
		}
	}




file_put_contents($file, $data, FILE_APPEND | LOCK_EX);


?>