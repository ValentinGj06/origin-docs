<?php
// set location
// $ver = "";

//set map api url
$url = "https://ad.betcity.ru/d/off/events?rev=6&ver=115&lng=1&csn=ooca9s";
echo '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">';
// $url = "events";
echo '<table class="table table-striped table-bordered table-dark">';
//call api
$json = file_get_contents($url);
$json = json_decode($json);
foreach ($json->reply->sports->{3}->chmps as $championship) {
	$name = $championship->name_ch;
	if(strpos($name, 'Cyberbasketball') !== false ){
		echo '<thead>
				<tr class="table-active">
				  <th scope="col" colspan="4" class="text-right">League Name:</th>
			      <th scope="col" colspan="11" class="text-left">'.$name.'</th>
			    </tr>
			    <tr class="thead-light">
			      <th scope="col">#</th>
			      <th scope="col">id_ev</th>
			      <th scope="col">date_ev_str</th>
			      <th scope="col">name_ht</th>
			      <th scope="col">name_at</th>
			      <th scope="col">1</th>
			      <th scope="col">X</th>
			      <th scope="col">2</th>
			      <th scope="col">H1</th>
			      <th scope="col">ODDS</th>
			      <th scope="col">H2</th>
			      <th scope="col">ODDS</th>
			      <th scope="col">TOT</th>
			      <th scope="col">U</th>
			      <th scope="col">O</th>

			    </tr>
			  </thead>';
			echo '<tbody>';
		$i = 1;
		foreach ($championship->evts as $events) {
			$id = $events->id_ev;

			$date = date_create($events->date_ev_str);
			date_sub($date,date_interval_create_from_date_string("1 hour"));
			$date = date_format($date,"Y-m-d H:i");
			// $date = $events->date_ev_str;	
			$name_ht = $events->name_ht;	
			$name_at = $events->name_at;	

			echo '<tr>
				      <th scope="row">'.$i.'</th>
				      <td>'.$id.'</td>
				      <td>'.$date.'</td>
				      <td>'.$name_ht.'</td>
				      <td>'.$name_at.'</td>';

				      $p1_kf = 1;
				      $x_kf = 1;
				      $p2_kf = 1;
				      $handicap_negative = 0;
				      $handicap_kf = 1;
				      $handicap_positive = 0;
				      $handicap_kf = 1;
				      $total = 0;
				      $total_p1_kf = 1;
				      $total_p2_kf = 1;

				      foreach ($events->main as $main) {

				      	/* If it's Full Time result */
				      	if ($main->order === 1) {
				      		if (isset($main->data->$id->blocks->Wm->P1->kf) && $main->data->$id->blocks->Wm->P1->kf !== '' && $main->data->$id->blocks->Wm->P1->kf !== 0) {
				      		$p1_kf = round($main->data->$id->blocks->Wm->P1->kf, 2);
					      	} else {
					      		$p1_kf = 1;
					      	}

				      		$x_kf = 1;

				      		if (isset($main->data->$id->blocks->Wm->P2->kf) && $main->data->$id->blocks->Wm->P2->kf !== '' && $main->data->$id->blocks->Wm->P2->kf !== 0) {
					      		$p2_kf = round($main->data->$id->blocks->Wm->P2->kf, 2);
				      		} else {
					      		$p2_kf = 1;
					      	}

				      	/* If it's Handicap */
				      	} elseif ($main->order === 4) {

				      		
				      		if (isset($main->data->$id->blocks->F1m->Kf_F2->kf) && $main->data->$id->blocks->F1m->Kf_F2->kf !== '' && $main->data->$id->blocks->F1m->Kf_F2->kf !== 0) {

				      			$handicap_kf = $main->data->$id->blocks->F1m->Kf_F2->kf;

				      		} else {
					      		$handicap_kf = 1;
					      	}

				      		$handicap_positive = $main->data->$id->blocks->F1m->F2;
				      		$handicap_negative = $main->data->$id->blocks->F1m->F2 * -1;


				      	/* If it's Total */
				      	} elseif ($main->order === 5) {

				      		if (isset($main->data->$id->blocks->T1m->Tm->kf) && $main->data->$id->blocks->T1m->Tm->kf !== '' && $main->data->$id->blocks->T1m->Tm->kf !== 0) {

				      		$total_p1_kf = $main->data->$id->blocks->T1m->Tm->kf;

				      		} else {
					      		$total_p1_kf = 1;
					      	}


				      		if (isset($main->data->$id->blocks->T1m->Tb->kf) && $main->data->$id->blocks->T1m->Tb->kf !== '' && $main->data->$id->blocks->T1m->Tb->kf !== 0) {

				      		$total_p2_kf = $main->data->$id->blocks->T1m->Tb->kf;

				      		} else {
					      		$total_p2_kf = 1;
					      	}

				      		$total = $main->data->$id->blocks->T1m->Tot;
				      	}

				      }
		      	echo '<td>'.$p1_kf.'</td>
				      <td>'.$x_kf.'</td>
				      <td>'.$p2_kf.'</td>
				      <td>'.$handicap_negative.'</td>
				      <td>'.$handicap_kf.'</td>
				      <td>'.$handicap_positive.'</td>
				      <td>'.$handicap_kf.'</td>
				      <td>'.$total.'</td>
				      <td>'.$total_p1_kf.'</td>
				      <td>'.$total_p2_kf.'</td>
				    </tr>';
			$i++;
		}
			echo '</tbody>';
	}
}
	echo '</table>';
