<!doctype html>
<html>
<head lang="en">
<meta charset="utf-8">
<title>Прати Маил</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<link rel="stylesheet" href="css/style.css">

</head>
<body>
<div>
	<div class="row">
		<div class="col">
			<h1>Форма за испраќање на маил пораки</h1>
			<hr> 
			<form id="form" action="listMail.php" method="POST" enctype="multipart/form-data">
				<div class="form-group">
				    <label for="mail_subject">Предмет на Порака</label>
				    <input required type="text" class="form-control" name="mail_subject" id="mail_subject" aria-describedby="subjectHelp" placeholder="на пр. Промоција">
				    <small id="subjectHelp" class="form-text text-muted">Напишете предмет на пораката.</small>
				</div>
				<div class="form-group">
				    <label for="mail_body">Порака</label>
				    <textarea required type="text" class="form-control" name="mail_body" id="mail_body" placeholder="на пр. Почитувани..."></textarea>
				</div>
				<div class="form-group">
				    <label for="mail_alt_body">Алтернативна Порака</label>
				    <textarea type="text" class="form-control" name="mail_alt_body" id="mail_alt_body" aria-describedby="altBodyHelp" placeholder="на пр. Здраво..."></textarea>
				    <small id="altBodyHelp" class="form-text text-muted">Напишете алтернативна порака.</small>
				</div>
				<div class="form-group">
					<span class="btn btn-primary btn-file">Прикачи фајл &nbsp
						<svg class="bi bi-upload" width="1em" height="1em" viewBox="0 0 16 12" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
						  <path fill-rule="evenodd" d="M.5 8a.5.5 0 0 1 .5.5V12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8.5a.5.5 0 0 1 1 0V12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8.5A.5.5 0 0 1 .5 8zM5 4.854a.5.5 0 0 0 .707 0L8 2.56l2.293 2.293A.5.5 0 1 0 11 4.146L8.354 1.5a.5.5 0 0 0-.708 0L5 4.146a.5.5 0 0 0 0 .708z"/>
						  <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-1 0v-8A.5.5 0 0 1 8 2z"/>
						</svg>
						<input required id="uploadImage" data-filename="Choose File..." type="file" accept=".xlsx, .xls, .csv" name="fileToUpload" />
					</span>
					<span class="file-control ml-2" data-filename=""></span>
				</div>
			<!-- <div id="preview"><img src="filed.png" /></div><br> -->
				<!-- <button type="submit" class="btn btn-primary">Прати</button> -->
				<button type="submit" class="button btn">
				    <span class="default">Send</span>
				    <span class="success">
				        <svg viewBox="0 0 16 16">
				            <polyline points="3.75 9 7 12 13 5"></polyline>
				        </svg>Sent
				    </span>
				    <svg class="trails" viewBox="0 0 33 64">
				        <path d="M26,4 C28,13.3333333 29,22.6666667 29,32 C29,41.3333333 28,50.6666667 26,60"></path>
				        <path d="M6,4 C8,13.3333333 9,22.6666667 9,32 C9,41.3333333 8,50.6666667 6,60"></path>
				    </svg>
				    <div class="plane">
				        <div class="left"></div>
				        <div class="right"></div>
				    </div>
				</button>
			</form>

			<div id="err"></div>
			<hr>
		</div>
	</div>
</div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.2.6/gsap.min.js"></script>

<script src="js/main.js"></script>


<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
  e.preventDefault();
  $.ajax({
         url: "listMail.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#err").fadeOut();
   },
   success: function(data)
      {
	    if(data=='invalid')
	    {
	     // invalid file format.
	     $("#err").html("Invalid File !").fadeIn();
	    }
	    else
	    {
	     // view uploaded file.
	     $("#preview").html(data).fadeIn();
	     $("#form")[0].reset(); 
	    }
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
 }));
});

$(document).ready(function(){
        $('input[type="file"]').change(function(e){
            var fileName = e.target.files[0].name;
            var fileMessage = 'The file "' + fileName +  '" has been selected.';
            $('span[class="file-control ml-2"]').attr('data-filename', fileMessage);
        });
    });
</script>

</html>